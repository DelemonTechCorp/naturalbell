from django.contrib import admin
from .models import *
# Register your models here.
@admin.register(Patient)
class PatientAdmin(admin.ModelAdmin):
    list_display = ('name','patient_id', 'doctor','treatment', 'gender','status', 'age', 'phone', 'email', 'address','note')
    search_fields = ('name', 'phone', 'email')

@admin.register(Login)
class LoginAdmin(admin.ModelAdmin):
    list_display = ('username', 'password', 'type')
    search_fields = ('username', 'type')

@admin.register(Room)
class RoomAdmin(admin.ModelAdmin):
    list_display = ('RoomNumber',)
    search_fields = ('RoomNumber',)

@admin.register(Admin)
class AdminAdmin(admin.ModelAdmin):
    list_display = ('Name', 'phone', 'email')
    search_fields = ('Name', 'phone', 'email')

@admin.register(Doctor)
class DoctorAdmin(admin.ModelAdmin):
    list_display = ('name', 'contact_no', 'email_id', 'place', 'gender','Speciality','About','DOB','Image')
    search_fields = ('name', 'contact_no', 'email_id')

@admin.register(Therapy)
class TherapyAdmin(admin.ModelAdmin):
    list_display = ('Therapy',)
    search_fields = ('Therapy',)

@admin.register(Therapist)
class TherapistAdmin(admin.ModelAdmin):
    list_display = ('name', 'specialization', 'contact_no', 'email_id', 'place', 'gender', 'Room','Image')
    search_fields = ('name', 'contact_no', 'email_id')

@admin.register(booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('Doctor','status', 'patientid','treatment', 'reg_date', 'reg_time','about')
    search_fields = ('Doctor__name', 'patientid__name', 'reg_date')

@admin.register(Schedule)
class ScheduleAdmin(admin.ModelAdmin):
    list_display = ('patientid', 'status','Therapist', 'Therapy', 'Date', 'number_of_session', 'starting_Time', 'ending_Time')
    search_fields = ('patientid__name', 'Therapist__name', 'Therapy__Therapy', 'Date')
@admin.register(Status)
class StatusAdmin(admin.ModelAdmin):
    list_display = ['Status', 'color']
@admin.register(SessionStatus)
class SessionStatusAdmin(admin.ModelAdmin):
    list_display = ['session_date','session_group', 'ending_Time','starting_Time','status','schedule','session_number']
# @admin.register(casesheet)
# class CaseSheetAdmin(admin.ModelAdmin):
#     list_display = (
#         'patientid', 'Followup', 'Proposedtreatmentplan', 'Treatment', 'Srothusinvolved', 'Dhathupredominence',
#         'Doshapredominence', 'Amanirama', 'Regularmedications', 'PastMedicalandsurgicalhistory', 'Historyofpresentingcomplaints',
#         'Presentingcomplaints', 'Menstrualhistory', 'Allergies', 'Sleep', 'Digestion', 'Clinicaldetails'
#     )
#     search_fields = (
#         'patientid__name', 'Followup', 'Proposedtreatmentplan', 'Treatment', 'Srothusinvolved', 'Dhathupredominence',
#         'Doshapredominence', 'Amanirama', 'Regularmedications', 'PastMedicalandsurgicalhistory', 'Historyofpresentingcomplaints',
#         'Presentingcomplaints', 'Menstrualhistory', 'Allergies', 'Sleep', 'Digestion', 'Clinicaldetails'
#     )